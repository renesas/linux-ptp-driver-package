Contents
========
  Revision History
  Introduction
      File Contents
  Kernel Dependencies
      PHC Adjust Phase
      ptp_schedule_worker
  Linux Kernel 5.4.2
  Apply Patch Files
      Introduce Phase Adjust to PHC API
      Add Renesas MFD/PTP/MISC Drivers
  Configuration
      Verify .config
  Device Tree Entry
      Sample I2C Entry ClockMatrix
      Sample I2C Entry Sabre
      Sample SPI Entry ClockMatrix
  Test Build Drivers
      Verify Drivers Configured and Compiled
  Example Loading of Drivers on Xilinx ZCU102 Board


Revision History
================
pcm4l 4.2.0 and above   Renesas_MFD_PTP_MISC_patches_2022_07_25_5ecd2144.tar.gz
pcm4l 4.1.4 and above	Renesas_MFD_PTP_MISC_patches_2022_02_24_e9d9162c.tar.gz
pcm4l 4.1.3 and below	Renesas_MFD_PTP_MISC_patches_2021_09_17_59227acc.tar.gz


Introduction
============
The patch files were created on against Linux 5.16.9

For reference, the resulting patched files are in the corresponding drivers and include directories.

File Contents
-------------
.
├── 0001-Introduce-adjphase-to-PHC-API.patch
├── 0001-mfd-Kconfig-and-Makefile-rmsu_i2c-and-rsmu_spi.patch
├── 0002-mfd-Add-rmsu_i2c-and-rsmu_spi-driver-files.patch
├── 0003-ptp-Kconfig-and-Makefile-ptp_clockmatrix-and-ptp_idt.patch
├── 0004-ptp-Add-ptp_clockmatrix-and-ptp_idt82p33.patch
├── 0005-misc-Kconfig-and-Makefile-rsmu.patch
├── 0006-misc-Add-rsmu_cdev-rsmu_cm-rsmu_sabre.patch
├── drivers
│   ├── mfd
│   │   ├── Kconfig
│   │   ├── Makefile
│   │   ├── rsmu_core.c
│   │   ├── rsmu.h
│   │   ├── rsmu_i2c.c
│   │   └── rsmu_spi.c
│   ├── misc
│   │   ├── Kconfig
│   │   ├── Makefile
│   │   ├── rsmu_cdev.c
│   │   ├── rsmu_cdev.h
│   │   ├── rsmu_cm.c
│   │   └── rsmu_sabre.c
│   └── ptp
│       ├── Kconfig
│       ├── Makefile
│       ├── ptp_chardev.c
│       ├── ptp_clock.c
│       ├── ptp_clockmatrix.c
│       ├── ptp_clockmatrix.h
│       ├── ptp_idt82p33.c
│       └── ptp_idt82p33.h
├── include
│   ├── linux
│   │   ├── mfd
│   │   │   ├── idt82p33_reg.h
│   │   │   ├── idt8a340_reg.h
│   │   │   └── rsmu.h
│   │   └── ptp_clock_kernel.h
│   └── uapi
│       └── linux
│           ├── ptp_clock.h
│           └── rsmu.h
└── README.txt

Kernel Dependencies
===================

PHC Adjust Phase
----------------
The PHC Adjust support was added in v5.8

ptp_schedule_worker
-------------------
The ptp_schedule_worker was added in v4.13


Linux Kernel 5.16.9
===================
git clone https://git.kernel.org/pub/scm/linux/kernel/git/stable/linux.git linux-stable
cd linux-stable
git checkout v5.16.9

The patch files were generated on Linux Kernel v5.16.9.


Apply Patch Files
=================
If the repository has previous Renesas MFD/PTP/MISC drivers, please remove the 
files and Kconfig/Makefile entries prior to applying the patch files.

Create a patches directory in the linux root directory.
Copy the patch files to the <linux_root>/patches directory.

From the <linux_root> directory do the following patch commands below:

Introduce Phase Adjust to PHC API
---------------------------------
Skip this if using v5.8 or above.

patch -p1 < patches/0001-Introduce-adjphase-to-PHC-API.patch
 
Add Renesas MFD/PTP/MISC Drivers
--------------------------------
These patch files may fail depending on the Linux Kernel versions.
  0001-mfd-Kconfig-and-Makefile-rmsu_i2c-and-rsmu_spi.patch
  0003-ptp-Kconfig-and-Makefile-ptp_clockmatrix-and-ptp_idt.patch 
Please manually insert the required lines in the corresponding files.

patch -p1 < patches/0001-mfd-Kconfig-and-Makefile-rmsu_i2c-and-rsmu_spi.patch
patch -p1 < patches/0002-mfd-Add-rmsu_i2c-and-rsmu_spi-driver-files.patch
patch -p1 < patches/0003-ptp-Kconfig-and-Makefile-ptp_clockmatrix-and-ptp_idt.patch
patch -p1 < patches/0004-ptp-Add-ptp_clockmatrix-and-ptp_idt82p33.patch
patch -p1 < patches/0005-misc-Kconfig-and-Makefile-rsmu.patch
patch -p1 < patches/0006-misc-Add-rsmu_cdev-rsmu_cm-rsmu_sabre.patch


Configuration
=============
make menuconfig

Select the following, adjust I2C or SPI as required.

Device Drivers  --->
    [*] Device Tree and Open Firmware support  ----
    <Save>
 
    Multifunction device drivers  --->
        <M> Renesas Synchronization Management Unit with I2C (NEW)
        < > Renesas Synchronization Management Unit with SPI (NEW)
    <Save>
 
    PTP clock support  --->
        <M> IDT CLOCKMATRIX as PTP clock (NEW)
        <M> IDT 82P33xxx PTP clock (NEW)
    <Save>
 
    Misc devices  --->
        <M> Renesas Synchronization Management Unit (SMU) (NEW)
    <Save>


Verify .config
--------------
...
CONFIG_OF=y
...
#
# PTP clock support
#
CONFIG_PTP_1588_CLOCK=m
CONFIG_PTP_1588_CLOCK_IDTCM=m
CONFIG_PTP_1588_CLOCK_IDT82P33=m
...
#
# Misc devices
#
CONFIG_RSMU=m
...
#
# Multifunction device drivers
#
CONFIG_MFD_CORE=m
CONFIG_MFD_RSMU_I2C=m


Device Tree Entry
=================

Sample I2C Entry ClockMatrix
----------------------------
	phc@5b {
		compatible = "idt,8a34000";
		reg = <0x5b>;
	};

Sample I2C Entry Sabre
----------------------
	phc@51 { /* Sabre */
		compatible = "idt,82p33810";
		reg = <0x51>;
	};


Sample SPI Entry ClockMatrix
----------------------------
	phc@0 { 
		compatible = "idt,8a34000";
		spi-max-frequency = <10000000>;
		reg = <0>;
	};


Test Build Drivers
==================
# Compile drivers/ptp directory
make -j $(nproc) drivers/ptp/
 
# Compile drivers/mfd directory
make -j $(nproc) drivers/mfd/
 
# Compile drivers/misc directory
make -j $(nproc) drivers/misc/


Verify Drivers Configured and Compiled
--------------------------------------
ls -1 drivers/mfd/rsmu*.o
drivers/mfd/rsmu_core.o
drivers/mfd/rsmu_i2c.o
drivers/mfd/rsmu-i2c.o
 
ls -1 drivers/misc/rsmu*.o
drivers/misc/rsmu_cdev.o
drivers/misc/rsmu_cm.o
drivers/misc/rsmu.o
drivers/misc/rsmu_sabre.o
 
ls -1 drivers/ptp/*.o
drivers/ptp/ptp_chardev.o          
drivers/ptp/ptp_clockmatrix.o  
drivers/ptp/ptp_clock.o
drivers/ptp/ptp_idt82p33.o
drivers/ptp/ptp.o
 

Example Loading of Drivers on Xilinx ZCU102 Board
=================================================
root@pl_eth_1g_ptp_zcu102_cm:/# lsmod
    Tainted: G
macb 53248 0 - Live 0xffffff8000a60000
uio_pdrv_genirq 16384 0 - Live 0xffffff8000a50000


root@pl_eth_1g_ptp_zcu102_cm:/# modprobe rsmu-i2c
[629114.760375] rsmu-cdev 82p33x1x-cdev.1.auto: Probe rsmu0 successful
[629114.766984] rsmu-cdev 8a3400x-cdev.3.auto: Probe rsmu1 successful


root@pl_eth_1g_ptp_zcu102_cm:/# lsmod
    Tainted: G
rsmu 16384 0 - Live 0xffffff8000a76000 (O)
rsmu_i2c 16384 0 - Live 0xffffff8000a6e000 (O)
macb 53248 0 - Live 0xffffff8000a60000
uio_pdrv_genirq 16384 0 - Live 0xffffff8000a50000


root@pl_eth_1g_ptp_zcu102_cm:/# modprobe ptp_clockmatrix firmware=idtcm.bin.8A3400x_G.8275.2_APTS_50MHz_v4_propinteg
[214578.372291] 8a3400x-phc 8a3400x-phc.0.auto: 4.8.7, Id: 0x4001  HW Rev: 5  OTP Config Select: 15
[214578.381078] 8a3400x-phc 8a3400x-phc.0.auto: requesting firmware 'idtcm.bin.8A3400x_G.8275.2_APTS_50MHz_v4_propinteg'
[214581.606475] 8a3400x-phc 8a3400x-phc.0.auto: PLL2 registered as ptp1


root@pl_eth_1g_ptp_zcu102_cm:/# lsmod
    Tainted: G
ptp_clockmatrix 32768 0 - Live 0xffffff8000a7e000 (O)
rsmu 16384 0 - Live 0xffffff8000a76000 (O)
rsmu_i2c 16384 0 - Live 0xffffff8000a6e000 (O)
macb 53248 0 - Live 0xffffff8000a60000
uio_pdrv_genirq 16384 0 - Live 0xffffff8000a50000


root@pl_eth_1g_ptp_zcu102_cm:/# cat /sys/class/ptp/ptp1/clock_name
IDT CM TOD2





